package com.liquidglass.dialer;

import android.app.*;
import android.content.*;
import android.os.*;
import android.telecom.*;

public class DialerInCallService extends InCallService {
    static Call activeCall;
    static DialerInCallService activeService;
    static boolean muted=false, speaker=false;
    @Override public void onCreate(){super.onCreate();activeService=this;}
    @Override public void onDestroy(){if(activeService==this)activeService=null;super.onDestroy();}
    @Override public void onCallAudioStateChanged(CallAudioState state){super.onCallAudioStateChanged(state);speaker=state.getRoute()==CallAudioState.ROUTE_SPEAKER;}
    @Override public void onCallAdded(Call call){super.onCallAdded(call);activeCall=call;call.registerCallback(callback);showCallUi(call);}
    @Override public void onCallRemoved(Call call){super.onCallRemoved(call);call.unregisterCallback(callback);if(activeCall==call)activeCall=null;NotificationManager nm=getSystemService(NotificationManager.class);if(nm!=null)nm.cancel(20);}
    private final Call.Callback callback=new Call.Callback(){@Override public void onStateChanged(Call c,int s){showCallUi(c);}};
    private void showCallUi(Call call){
        String number="Unknown caller";try{if(call.getDetails().getHandle()!=null)number=call.getDetails().getHandle().getSchemeSpecificPart();}catch(Exception ignored){}
        Intent i=new Intent(this,CallActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);i.putExtra("number",number);
        PendingIntent pi=PendingIntent.getActivity(this,2,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationManager nm=getSystemService(NotificationManager.class);if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel("calls","Phone calls",NotificationManager.IMPORTANCE_HIGH));
        Notification n=new Notification.Builder(this,"calls").setSmallIcon(android.R.drawable.sym_action_call).setContentTitle("Phone call").setContentText(number).setCategory(Notification.CATEGORY_CALL).setFullScreenIntent(pi,true).setContentIntent(pi).setOngoing(true).build();
        nm.notify(20,n);
    }
}
