package com.liquidglass.dialer;

import android.app.Activity;
import android.os.Bundle;
import android.telecom.Call;
import android.view.Gravity;
import android.widget.*;

public class CallActivity extends Activity {
    private boolean muted=false;
    private TextView state,number;
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().addFlags( android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);render();}
    private void render(){LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setGravity(Gravity.CENTER);root.setPadding(28,28,28,28);root.setBackgroundColor(0xFF101827);
        number=new TextView(this);number.setText(getIntent().getStringExtra("number"));number.setTextColor(0xFFFFFFFF);number.setTextSize(28);root.addView(number);
        state=new TextView(this);state.setTextColor(0xFFB7D6E8);state.setTextSize(17);state.setPadding(0,20,0,40);root.addView(state);
        Call c=DialerInCallService.activeCall;int s=c==null?-1:c.getState();state.setText(label(s));
        if(s==Call.STATE_RINGING){add(root,"Answer",()->{if(c!=null)c.answer(0);});add(root,"Decline",()->{if(c!=null)c.reject(false,null);finish();});}
        else {add(root,"Mute / unmute",()->CallControl.perform(this,"mute"));add(root,"Speaker",()->CallControl.perform(this,"speaker"));add(root,"Hold / resume",()->CallControl.perform(this,"hold"));add(root,"End call",()->{CallControl.perform(this,"end");finish();});}
        setContentView(root);
    }
    @Override protected void onNewIntent(android.content.Intent intent){super.onNewIntent(intent);setIntent(intent);render();}
    private String label(int s){if(s==Call.STATE_RINGING)return "Incoming call";if(s==Call.STATE_DIALING)return "Calling…";if(s==Call.STATE_ACTIVE)return "Connected";if(s==Call.STATE_HOLDING)return "On hold";return "Call status";}
    private void add(LinearLayout r,String text,Runnable action){Button b=new Button(this);b.setText(text);b.setAllCaps(false);r.addView(b,new LinearLayout.LayoutParams(-1,-2));b.setOnClickListener(v->action.run());}
}
